import UIKit

var sayiListesi : [Double] = [2,4,6,8,10,14,36,56,45,65,34,1,3,5]

func kontrol (sayilar : [Double], sonucFonksiyonu : ((String)->Void), ortalamaFonksiyonu : ((Double)->Void))
{
    
    if sayiListesi.count < 10
    {
        sonucFonksiyonu("Eleman sayisi yetersiz")
    }
    else
    {
        var toplam : Double = 0
        
        for i in sayiListesi
        {
            toplam += i
        }
        let ortalama = toplam / Double(sayiListesi.count)
        
        ortalamaFonksiyonu(ortalama)
    }
}

func ort (ortalama : Double)
{
    print("Liste ortalamasi : \(ortalama)")
}
func sonuc (deger : String)
{
    print(deger)
}

kontrol(sayilar: sayiListesi, sonucFonksiyonu: sonuc, ortalamaFonksiyonu: ort)

