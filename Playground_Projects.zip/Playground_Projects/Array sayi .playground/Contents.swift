import UIKit

var sayilar = [1,2,3,4,5,6,7,8,9]

var tekler = [Int] ()
var ciftler = [Int] ()

for s in sayilar {
    
    let sonuc = s % 2
    
    if sonuc == 0 {
        ciftler.append(s)
    }
    
    else  {
        tekler.append(s)
    }
}
print("Tek sayilar: \(tekler)")

print("Cift sayilar: \(ciftler)")


