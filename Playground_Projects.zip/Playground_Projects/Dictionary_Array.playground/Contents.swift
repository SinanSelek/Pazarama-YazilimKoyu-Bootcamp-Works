import UIKit

var ogrenci = [ [String : Int ] ] ()
var ogrAli : [String : Int] =
    [
        "no" : 101,
        "vize" : 80,
        "final" : 60
    ]
ogrenci.append(ogrAli)
var ogrVeli : [String : Int] =
    [
        "no" : 102,
        "vize" : 70,
        "final" : 80
    ]
ogrenci.append(ogrVeli)
var ogrMert : [String : Int] =
    [
        "no" : 103,
        "vize" : 40,
        "final" : 70
    ]
ogrenci.append(ogrMert)
for i in ogrenci
{
    let vize : Float = Float(i["vize"]!)
    let final : Float = Float(i["final"]!)
    let no : Int = i["no"]!
    
    let ort : Float = (vize + final) / 2
    
    print("\(no) : \(ort)" )
}
