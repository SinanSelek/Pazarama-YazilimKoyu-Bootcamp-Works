//
//  ViewController.swift
//  Login_Ekranı
//
//  Created by Sinan Selek on 27.08.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

