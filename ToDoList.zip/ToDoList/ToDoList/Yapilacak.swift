//
//  Yapilacak.swift
//  ToDoList
//
//  Created by Sinan Selek on 13.09.2022.
//

import Foundation

class Yapilacak
{
    var baslik : String!
    var aciklama : String!
    var detay : String!
}
