//
//  VC_Detay.swift
//  ToDoList
//
//  Created by Sinan Selek on 13.09.2022.
//

import UIKit
import CoreData

class VC_Detay: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var tfBaslik: UITextField!
    @IBOutlet weak var tfAciklama: UITextField!
    @IBOutlet weak var tfDetay: UITextField!
    
    var yapilacak : Yapilacak!
    var isUpdate = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tfAciklama.delegate = self

        if yapilacak == nil
        {
            yapilacak = Yapilacak()
        }
        else
        {
            tfBaslik.text = yapilacak.baslik
            tfAciklama.text = yapilacak.aciklama
            tfDetay.text = yapilacak.detay
            
            isUpdate = true
            
        }
        
    }
    
    @IBAction func btnKaydet_TUI(_ sender: Any) {
        let mesaj = zorunlulukKontrolleri()
        
        if mesaj == ""
        {
            yapilacak.baslik = tfBaslik.text
            yapilacak.aciklama = tfAciklama.text
            yapilacak.detay = tfDetay.text
            
            if !isUpdate
            {
                Globals.Yapilacaklar.append(yapilacak)
            }
            
            navigationController!.popViewController(animated: true)
        }
        else
        {
            let ac = UIAlertController(title: "Error", message: mesaj, preferredStyle: .alert)
            
            ac.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            
            present(ac, animated: true, completion: nil)
        }
        // veri kaydet
        func getContext() -> NSManagedObjectContext
        {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            
            return appDelegate.persistentContainer.viewContext
        }
        
        let context = getContext()
        let entity = NSEntityDescription.entity(forEntityName: "Todo", in: context)
        let list = NSManagedObject(entity: entity!, insertInto: context)
        
        list.setValue(tfBaslik.text, forKey: "baslik")
        list.setValue(tfAciklama.text, forKey: "aciklama")
        list.setValue(tfDetay.text, forKey: "detay")
        
        do
        {
            try context.save()
            print("Saved")
        }
        catch {print("Error")}
    }
    
    
    func zorunlulukKontrolleri()->String
    {
        var mesaj = ""
        if tfBaslik.text == ""
        {
            mesaj += "Başlık boş olamaz."
        }
        
        return mesaj
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let textFieldText = tfAciklama.text,
              let rangeOfTextToReplace = Range(range, in: textFieldText) else {
            return false
        }
        let substringToReplace = textFieldText[rangeOfTextToReplace]
        let count = textFieldText.count - substringToReplace.count + string.count
        return count <= 10
        
    }

}
