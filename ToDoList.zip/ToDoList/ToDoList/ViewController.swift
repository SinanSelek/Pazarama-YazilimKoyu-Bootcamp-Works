//
//  ViewController.swift
//  ToDoList
//
//  Created by Sinan Selek on 13.09.2022.
//

import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var tvListe: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        tvListe.reloadData()
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Globals.Yapilacaklar.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = Bundle.main.loadNibNamed("TVC_Yapilacak", owner: self, options: nil)?.first as! TVC_Yapilacak
        
        let k = Globals.Yapilacaklar[indexPath.row]
        
        cell.lblBaslik.text = k.baslik
        cell.lblAciklama.text = k.aciklama
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "sgGuncelle", sender: indexPath.row)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete
        {
            Globals.Yapilacaklar.remove(at: indexPath.row)
            tvListe.reloadData()
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "sgGuncelle"
        {
            let vc = segue.destination as! VC_Detay
            vc.yapilacak = Globals.Yapilacaklar[sender as! Int]
        }
        
    }
    
    // veriler getir
    
    func getData ()
    {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Todo")
        
        do
        {
            let veriler = try context.fetch(fetchRequest)
            
            print(veriler)
        }
        catch{}
    }
   

}

