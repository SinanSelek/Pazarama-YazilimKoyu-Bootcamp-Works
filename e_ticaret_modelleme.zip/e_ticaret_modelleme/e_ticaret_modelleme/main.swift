//
//  main.swift
//  e_ticaret_modelleme
//
//  Created by Sinan Selek on 19.08.2022.
//

import Foundation

class Kategori
{
    var Ad : String
    var UstKategori : Kategori?
    
    init(ad : String, ustKategori : String)
    {
        Ad = ad
    }
}

class Urun
{
    var Marka : Marka
    var Ad : String
    var KisaAciklama : String
    var DetayAciklama : String
    var Fiyat : Double?
    var kategori = [Kategori]()
    
    init (marka : Marka, ad : String, kisaAciklama : String, detayAciklama : String)
    {
        Marka = marka
        Ad = ad
        KisaAciklama = kisaAciklama
        DetayAciklama = detayAciklama
    }
    
}

class Marka
{
    var Ad : String
    
    init (ad : String)
    {
        Ad = ad
    }
}
