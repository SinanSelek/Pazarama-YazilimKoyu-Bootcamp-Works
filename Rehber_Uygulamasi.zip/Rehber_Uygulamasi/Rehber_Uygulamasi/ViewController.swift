//
//  ViewController.swift
//  Rehber_Uygulamasi
//
//  Created by Sinan Selek on 8.09.2022.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var rehber = ["Sinan S   05551112233", "Meryem S  05552223344"]
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return rehber.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = Bundle.main.loadNibNamed("TVC_Rehber", owner: self)?.first as! TVC_Rehber
        
        cell.lblMetin.text = rehber[indexPath.row]
        
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

