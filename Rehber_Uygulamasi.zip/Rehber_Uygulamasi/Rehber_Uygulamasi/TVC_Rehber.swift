//
//  TVC_Rehber.swift
//  Rehber_Uygulamasi
//
//  Created by Sinan Selek on 8.09.2022.
//

import UIKit

class TVC_Rehber: UITableViewCell {

    @IBOutlet weak var lblMetin: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
