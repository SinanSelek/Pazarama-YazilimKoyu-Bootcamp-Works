//
//  DAL(DataAccessLayer).swift
//  07_LocalVeri
//
//  Created by Sinan Selek on 12.09.2022.
//

import Foundation
import CoreData
import UIKit

class DAL
{
    func getContext()-> NSManagedObjectContext
    {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        return appDelegate.persistentContainer.viewContext
    }
    
    func veriKaydet(veri1 : String, veri2 : String)
    {
        let context = getContext()
        let entity = NSEntityDescription.entity(forEntityName: "Veri", in: context)
        
        let v = NSManagedObject(entity: entity!, insertInto: context)
        
        v.setValue(veri1, forKey: "veri1")
        v.setValue(veri2, forKey: "veri2")
        
        do
        {
            try context.save()
        }
        catch {}
        
    }
    
    func verilerGetir()
    {
        let fetchRequest : NSFetchRequest<Veri> = Veri.fetchRequest()
        
       // fetchRequest.sortDescriptors = [NSSortDescriptor(key: "veri1", ascending: true)]
        //fetchRequest.predicate = NSPredicate(format: "veri1 == veri11")
       // fetchRequest.predicate = NSPredicate(format: "veri1 == %@", "veri11")
       // fetchRequest.predicate = NSPredicate(format: "veri1 contains 11")
        
       // fetchRequest.predicate = NSPredicate(format: "veri1 == veri11")
        
        
        do
        {
            let veriler = try getContext().fetch(fetchRequest)
            print(veriler)
        }
        catch {}
    }
    
    /*static func veriGuncelle (v : Veri)
    {
        v.veri1 = "fasa"
        
        try? getContext().save()
    }
    
    static func veriSil (v : Veri)
    {
        getContext().delete(v)
        
        try? getContext().save()
    }*/
}
