//
//  ViewController.swift
//  07_LocalVeri
//
//  Created by Sinan Selek on 12.09.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //userDefYaz(deger: "yazilan deger", key: "yd")
        
        let d = userDefOku(key: "yd")
        print(d)
        
    }
    
    // UserDefaults
    
    func userDefYaz(deger : String, key : String)
    {
        let userDefaults = UserDefaults.standard
        userDefaults.set(deger, forKey: key)
        
        userDefaults.synchronize()
    }
    
    func userDefOku(key : String)-> String
    {
        if let a = UserDefaults.standard.string(forKey: key)
        {
            return a
        }
        return ""
    }
    
    func userDefSil(key : String)
    {
        UserDefaults.standard.removeObject(forKey: key)
        UserDefaults.standard.synchronize()
    }


}

