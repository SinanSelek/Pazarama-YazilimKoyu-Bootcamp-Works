//
//  main.swift
//  00_SwiftGiris
//
//  Created by Sinan Selek on 8.08.2022.
//

import Foundation

/*var adi = 5

var sayi : Int

sayi = 10

var ondalikli : Float = 10.5

var dogru = true

var metin = "metin degeri"

var metin2 = "hdfhhsd"

metin2 = "gsk"

print("yas : " + String(10) )

var metin3 = "yas : \(ondalikli)"

var d1 : Double = 0.0
var i1 = 10
d1 = Double(i1) //tip donusumu

var t1 = (1, "metin", 3) // tuple veri girisi

print(t1.0)

var d2 : Double? // belirsizlik durumunda ? kullanilir

//d2 = 0.0

print(d2 ?? "bos") //deger yoksa default olarak bos yazar

// aritmetik operatorler

var i2 = 10
var i3 = 20

var toplam = i2 + i3 + Int(d1)

toplam = toplam + 1 // toplam += 1 (ayni islem)


// ve=&& veya=|| islemleri

// kosul operatorleri   -if yapisi   -switch-case yapisi

// if

var opInt : Int? = 10

if opInt != nil
{
    print("kucuk")
    
}
if let i = opInt
{
    print(i)
}

//switch-case
var sayac = 10
switch sayac
{
case 1:
    print("bir")
    
case 2:
    print("iki")
    
case 3,4:       // coklu case
    print("")
    
case 6-7:       // coklu case araligi
    print("")
    
case let a where a < 10 && a > 5:
    print("")
    
default:
    print("")
}



let deger = Int(readLine()!) ?? 0

if deger > 0 && deger < 40
{
    print("D")
}
else if deger >= 40 && deger < 60
{
    print("C")
}
else if deger >= 60 && deger < 80
{
    print("B")
}
else if deger >= 80 && deger <= 100
{
    print("A")
}
else
{
    print("gecersiz not girildi")
}

// Donguler

// While dongusu

var sayac1 = 10

while sayac1 < 12
{
    print(sayac1)
    sayac1 += 1
}

repeat
{
    print(sayac1)
    sayac1 += 1
} while sayac1 < 10 // kosul sonra kontrol edilir en az bir kez calisacak

// for dongusu

for i in 0..<10
{
    print(i)
    if i > 3
    {
        break // break donguyu kirar istedigimiz sartta
    }
    if i > 2
    {
        continue
    }
}

for i in stride(from: 0, to: 10, by: 2) // 0,2,4,6,8 sayilarini gezer
{
    print("")
}
*/

// 100 kisinin konumunu rastgele ureterek 1 km yakindaki kisi sayisini yazdiran kodu yazalim
var x : Double
var y : Double
var yakin = 0

for _ in 1...100
{
    x = Double.random(in: 0...1)
    y = Double.random(in: 0...1)
    
    if (x*x+y*y) <= 1
    {
        yakin += 1
    }
}

print("Yakin kisi sayisi : \(yakin)")

