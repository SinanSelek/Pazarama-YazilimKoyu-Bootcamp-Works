//
//  Globals.swift
//  Foto_Galeri
//
//  Created by Sinan Selek on 19.09.2022.
//

import Foundation

class Globals {
    static var Fotolar = [Foto]()
}
