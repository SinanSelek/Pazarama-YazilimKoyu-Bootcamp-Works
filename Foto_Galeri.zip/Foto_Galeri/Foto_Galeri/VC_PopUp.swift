//
//  VC_PopUp.swift
//  Foto_Galeri
//
//  Created by Sinan Selek on 18.09.2022.
//

import UIKit

class VC_PopUp: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate  {
    
    static var a : UIImage!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        //self.navigationController?.pushViewController(self, animated: false)

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnGaleri_TUI(_ sender: Any) {
        selectImage()
        
    
    }
    
    
    @IBAction func btnKamera_TUI(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(.camera)
        {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .camera
            present(imagePicker, animated: true)
        }
        else
        {
            print("Kamera yok")
        }
    }
    
    
    @IBAction func btnCikis_TUI(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    @objc func selectImage () {
        
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        VC_PopUp.a = info[.originalImage] as? UIImage
        self.dismiss(animated: true, completion: nil)
    }

}
