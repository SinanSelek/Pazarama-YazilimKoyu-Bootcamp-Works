//
//  CVC_Foto.swift
//  Foto_Galeri
//
//  Created by Sinan Selek on 18.09.2022.
//

import UIKit

class CVC_Foto: UICollectionViewCell {
    
    @IBOutlet weak var ivFoto: UIImageView!
}
