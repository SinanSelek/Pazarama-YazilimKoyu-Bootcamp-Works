//
//  Foto.swift
//  Foto_Galeri
//
//  Created by Sinan Selek on 16.09.2022.
//

import Foundation
import UIKit

class Foto
{
    var baslik : String!
    var yer : String!
    var aciklama : String!
    var fotograf : UIImage!
}


