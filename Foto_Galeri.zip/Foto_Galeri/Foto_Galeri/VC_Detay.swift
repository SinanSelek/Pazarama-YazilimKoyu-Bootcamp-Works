//
//  VC_Detay.swift
//  Foto_Galeri
//
//  Created by Sinan Selek on 16.09.2022.
//

import UIKit

class VC_Detay: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var ivDetay: UIImageView!
    @IBOutlet weak var tfBaslik: UITextField!
    @IBOutlet weak var tfYer: UITextField!
    @IBOutlet weak var tfAciklama: UITextField!
    
    @IBOutlet weak var btnSil: UIButton!
    
    var foto : Foto!
    var isUpdate = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ivDetay.isUserInteractionEnabled = true
        let imageTapRecognizer = UITapGestureRecognizer(target: self, action: #selector(selectImage))
        ivDetay.addGestureRecognizer(imageTapRecognizer)
        
        if foto == nil
        {
            foto = Foto()
            btnSil.isHidden = true
        }
        else
        {
            tfBaslik.text = foto.baslik
            tfYer.text = foto.yer
            tfAciklama.text = foto.aciklama
            ivDetay.image = foto.fotograf
            
            isUpdate = true
            ivDetay.isUserInteractionEnabled = false
            
        }
    }
    
    @IBAction func btnKaydet_TUI(_ sender: Any) {
        let mesaj = zorunlulukKontrolleri()
        
        if mesaj == ""
        {
            foto.baslik = tfBaslik.text
            foto.yer = tfYer.text
            foto.aciklama = tfAciklama.text
            foto.fotograf = ivDetay.image
            
            if !isUpdate
            {
                Globals.Fotolar.append(foto)
            }
            
            navigationController!.popViewController(animated: true)
            
        }
        else
        {
            let ac = UIAlertController(title: "Hata", message: mesaj, preferredStyle: .alert)
            
            ac.addAction(UIAlertAction(title: "Tamam", style: .default, handler: nil))
            
            present(ac, animated: true, completion: nil)
        }

        
    }
    
    @IBAction func btnSil_TUI(_ sender: Any) {

        let ac = UIAlertController(title: "Uyarı", message: "Fotoğrafı silmek istediğinize emin misiniz?", preferredStyle: .alert)
        
        ac.addAction(UIAlertAction(title: "Sil", style: .destructive, handler: { _ in
            self.foto.baslik = nil
            self.foto.yer = nil
            self.foto.aciklama = nil
            self.foto.fotograf = nil
            self.navigationController?.popViewController(animated: true)
        }))
        
        ac.addAction(UIAlertAction(title: "Vazgeç", style: .default, handler: nil))
        
        present(ac, animated: true, completion: nil)
    }
    
    func zorunlulukKontrolleri()->String
    {
        var mesaj = ""
        if tfBaslik.text == ""
        {
            mesaj += "Baslik boş olamaz."
        }
        
        return mesaj
    }
    
    @objc func selectImage () {
        
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        ivDetay.image = info[.originalImage] as? UIImage
        self.dismiss(animated: true, completion: nil)
    }
    
    
    @objc func popUp () {
        performSegue(withIdentifier: "sgPopUp", sender: nil)
    }
    

}
