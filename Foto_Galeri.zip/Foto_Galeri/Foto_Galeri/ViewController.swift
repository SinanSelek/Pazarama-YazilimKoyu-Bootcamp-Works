//
//  ViewController.swift
//  Foto_Galeri
//
//  Created by Sinan Selek on 16.09.2022.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout  {
    
    
    
    @IBOutlet weak var cvFoto: UICollectionView!


    override func viewDidLoad() {
        super.viewDidLoad()
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 5
        layout.minimumInteritemSpacing = 5
        cvFoto.setCollectionViewLayout(layout, animated: true)
        

    }
    
    override func viewDidAppear(_ animated: Bool) {
        cvFoto.reloadData()
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return  Globals.Fotolar.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as? CVC_Foto else {return UICollectionViewCell()}
        let k = Globals.Fotolar[indexPath.row]
        cell.ivFoto?.image = k.fotograf
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 1.0, left: 1.0, bottom: 1.0, right: 1.0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let gridLayout = collectionViewLayout as! UICollectionViewFlowLayout
        let widthPerItem = collectionView.frame.width / 3 - gridLayout.minimumInteritemSpacing
        return CGSize(width: widthPerItem, height: 120)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        performSegue(withIdentifier: "sgGuncelle", sender: indexPath.row)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "sgGuncelle"
        {
            let vc = segue.destination as! VC_Detay
            vc.foto = Globals.Fotolar[sender as! Int]
        
        }
    }
    
    static func sil(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        Globals.Fotolar.remove(at: indexPath.row)
        return  true
    }
    
    
    
}

