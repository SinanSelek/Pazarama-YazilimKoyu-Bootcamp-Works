//
//  ViewController.swift
//  01_SwiftGiris
//
//  Created by Sinan Selek on 14.08.2022.
//

import UIKit

/* class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}



var sayilar = [1,2,3,4,5,6,7,8,9]

var tekler = [Int] ()
var ciftler = [Int] ()

for s in sayilar {
    
    let sonuc = s % 2
    
    if sonuc == 0 {
        ciftler.append(s)
    }
    
    if sonuc == 1 {
        tekler.append(s)
    }
}
print("Tek sayilar:")
print(tekler)

print("Cift sayilar:")
print(ciftler)
*/
