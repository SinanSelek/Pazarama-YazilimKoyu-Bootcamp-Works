//
//  main.swift
//  Calisan_modellemesi
//
//  Created by Sinan Selek on 22.08.2022.
//

import Foundation

enum Rol
{
    case Mudur
    case MudurYardimcisi
    case Yazilimci
    case TemizlikGorevlisi
}

protocol CalisanProtokolu
{
    var sicilNo : Int{get set}
    var ad : String{get set}
    var soyad : String{get set}
    var gorev : Rol {get set}
    
    func izinKullanimi ()
}

protocol YoneticiProtokolu : CalisanProtokolu
{
    func kontrol ()
}


class Calisan : CalisanProtokolu
{
    var sicilNo: Int
    
    var ad: String
    
    var soyad: String
    
    var gorev: Rol
    
    func izinKullanimi()
    {
    
    }
    
    init (gorev : Rol)
    {
        sicilNo = 0
        ad = ""
        soyad = ""
        self.gorev = gorev
        
    }
    
}

class Yonetici : Calisan, YoneticiProtokolu
{
    func kontrol()
    {
        
    }
    
}

