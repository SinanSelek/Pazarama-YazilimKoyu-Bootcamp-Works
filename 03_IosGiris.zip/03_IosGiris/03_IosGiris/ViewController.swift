//
//  ViewController.swift
//  03_IosGiris
//
//  Created by Sinan Selek on 1.09.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var viewYesil: UIView!
    @IBOutlet weak var viewKirmizi: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewYesil.isHidden = false
        viewKirmizi.isHidden = true
    }

    @IBAction func btnSegmented(_ sender: UISegmentedControl) {
        
        switch sender.selectedSegmentIndex
        {
        case 0 :
            viewYesil.isHidden = false
            viewKirmizi.isHidden = true
        case 1 :
            viewYesil.isHidden = true
            viewKirmizi.isHidden = false
        default:
            break
        }
    }
    
}

