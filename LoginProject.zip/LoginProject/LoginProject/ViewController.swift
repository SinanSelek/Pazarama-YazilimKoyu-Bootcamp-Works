//
//  ViewController.swift
//  LoginProject
//
//  Created by Sinan Selek on 5.09.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelGiris: UILabel!
    @IBOutlet weak var textSifre: UITextField!
    @IBOutlet weak var textEposta: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        labelGiris.isHidden = true
    }

    @IBAction func butonGiris(_ sender: Any) {
        
        if textEposta.text == ""
        {
            makeAlert(titleInput: "Error", messageInput: "Username not found")
        }
        else if textSifre.text == ""
        {
            makeAlert(titleInput: "Error", messageInput: "Password not found")
        }

        else
        {
            labelGiris.isHidden = false
            
        }
        
    }
    
    func makeAlert(titleInput: String, messageInput: String)
    {
        let alert = UIAlertController(title: titleInput, message: messageInput, preferredStyle: UIAlertController.Style.alert)
        let okButton = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
        alert.addAction(okButton)
        self.present(alert, animated: true, completion: nil)
    }
}

