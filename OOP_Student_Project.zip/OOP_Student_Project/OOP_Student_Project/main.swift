//
//  main.swift
//  OOP_Student_Project
//
//  Created by Sinan Selek on 17.08.2022.
//

import Foundation

class Ogrenci
{
    var Ad : String
    var Soyad : String
    var No : Int
    var Dersler = [Ders]()
    
    init (adi : String, soyadi : String, nosu : Int)
    {
        Ad = adi
        Soyad = soyadi
        No = nosu
    }
    
    func durumHesapla()->String
    {
        var toplamNot = 0.0
        
        for ders in Dersler
        {
            toplamNot += ders.ort
        }
        
        return toplamNot / Double(Dersler.count) < 40 ? "Kaldi" : "Gecti"
    }
}

class Ders
{
    var Ad : String?
    var Vize : Double?
    var Final : Double?
    var ort : Double {
        ((Vize ?? 0.0) + (Final ?? 0.0))/2.0
    }
    
    init (ad : String)
    {
        Ad = ad
    }
    
}

var o1 = Ogrenci(adi: "ali", soyadi: "selek", nosu: 101)
var o2 = Ogrenci(adi: "veli", soyadi: "selek", nosu: 102)
var o3 = Ogrenci(adi: "sinan", soyadi: "selek", nosu: 103)

var d1 = Ders(ad: "O1D1")
var d2 = Ders(ad: "O1D2")

d1.Vize = 30
d1.Final = 80

d2.Vize = 60
d2.Final = 20

o1.Dersler.append(d1)
o1.Dersler.append(d2)

d1 = Ders(ad: "O2D1")
d2 = Ders(ad: "O2D2")

d1.Vize = 40
d1.Final = 90

d2.Vize = 80
d2.Final = 70

o2.Dersler.append(d1)
o2.Dersler.append(d2)

print("O1 Durum : \(o1.durumHesapla())")
print("O2 Durum : \(o2.durumHesapla())")
