//
//  ViewController.swift
//  LocationScreens
//
//  Created by Sinan Selek on 21.09.2022.
//


import UIKit
import CoreData

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
   
    @IBOutlet weak var cvVisit: UICollectionView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var tfDate: UITextField!
    @IBOutlet weak var tfLocExp: UITextField!

    
    var photos = [UIImage]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //date picker settings
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = .date
        datePicker.addTarget(self, action: #selector (dateChange(datePicker:)), for: UIControl.Event.valueChanged)
        datePicker.frame.size = CGSize(width: 0, height: 200)
        datePicker.preferredDatePickerStyle = .inline
        tfDate.inputView = datePicker
        tfDate.text = formatDate(date: Date())
        //cv settings 
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumInteritemSpacing = 1
        layout.minimumLineSpacing = 1
        cvVisit.setCollectionViewLayout(layout, animated: true)
        
        self.view.backgroundColor = UIColor(red: 0.898, green: 0.898, blue: 0.898, alpha: 1)
        
        
    }
    
    override func viewDidAppear(_ animated: Bool)
    {
        cvVisit.reloadData()
    }
    
    //date
    @objc func dateChange (datePicker: UIDatePicker)
    {
        tfDate.text = formatDate(date: datePicker.date)
        self.view.endEditing(true)
    }
    
    func formatDate (date: Date) -> String
    {
        let formatter = DateFormatter ()
        formatter.dateFormat = "dd.MM.yyyy"
        return formatter.string(from: date)
    }
    
    //collection view
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! CVC_Photo
        
        cell.ivPhoto?.image = photos[indexPath.row]
        
        return cell
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 76, height: 96)
    
    }
    
    

        // image picker
    func selectImage () {
        
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let k = info[.originalImage] as! UIImage
        photos.append(k)
        
        self.cvVisit.reloadData()
        self.dismiss(animated: true, completion: nil)
        
        
    }
    @IBAction func btnPhotoAdd_TUI(_ sender: Any) {
        selectImage()
        
    }
    
    @IBAction func btnBack_TUI(_ sender: Any) {
    }
    
    @IBAction func btnSave_TUI(_ sender: Any) {
       
        DAL.visitAdd(loc_explanation: tfLocExp.text!, visit_date: tfDate.text!)
        DAL.photoAdd(image: [photos[0]])
        //performSegue(withIdentifier: "toGezilecekler", sender: nil)
    
    }
}


