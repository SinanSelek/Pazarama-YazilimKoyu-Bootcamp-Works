//
//  Kisi.swift
//  Rehber_Projesi
//
//  Created by Sinan Selek on 10.09.2022.
//

import Foundation
import UIKit
class Kisi
{
    var Ad : String!
    var Soyad : String!
    var Telefon : String!
    var Resim : UIImage!
}
