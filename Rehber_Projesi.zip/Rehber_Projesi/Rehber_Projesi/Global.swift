//
//  Global.swift
//  Rehber_Projesi
//
//  Created by Sinan Selek on 15.09.2022.
//

import Foundation

class Globals {
    static var Kisiler = [Kisi]()
    static var Telefonlar = [Telefon]()
}
