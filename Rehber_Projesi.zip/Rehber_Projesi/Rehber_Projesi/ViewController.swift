//
//  ViewController.swift
//  Rehber_Projesi
//
//  Created by Sinan Selek on 10.09.2022.
//

import UIKit


class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var tvListe: UITableView!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        tvListe.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Globals.Kisiler.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "rehberId", for: indexPath) as! TVC_Rehber
        
        let k = Globals.Kisiler[indexPath.row]
        
        cell.lblAd.text = k.Ad + " " + k.Soyad
        
        cell.lblNumber.text = k.Telefon
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "sgGuncelle", sender: nil)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
             
            if editingStyle == .delete
            {
                Globals.Kisiler.remove(at: indexPath.row)
                tvListe.reloadData()
            }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue , sender: Any?) {
        if segue.identifier == "sgGuncelle" {
            
            let vc = segue.destination as! VC_KisiEkle
            vc.kisi = Globals.Kisiler[sender as! Int]
        }
    }

    
}

