//
//  TVC_Telefon.swift
//  Rehber_Projesi
//
//  Created by Sinan Selek on 15.09.2022.
//

import UIKit

class TVC_Telefon: UITableViewCell {

    @IBOutlet weak var lblTelefon: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
