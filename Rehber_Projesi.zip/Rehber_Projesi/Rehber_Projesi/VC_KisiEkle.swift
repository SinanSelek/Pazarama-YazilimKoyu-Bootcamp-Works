//
//  VC_KisiEkle.swift
//  Rehber_Projesi
//
//  Created by Sinan Selek on 12.09.2022.
//

import UIKit



class VC_KisiEkle: UIViewController {
    
    @IBOutlet weak var tfAd: UITextField!
    @IBOutlet weak var tfSoyad: UITextField!
    @IBOutlet weak var ivResim: UIImageView!
    
    var kisi : Kisi!
    var isUpdate = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if kisi == nil
        {
            kisi = Kisi()
        }
        else
        {
            tfAd.text = kisi.Ad
            tfSoyad.text = kisi.Soyad
            ivResim.image = kisi.Resim
            
            isUpdate = true
            
            tfAd.isEnabled = false
            tfSoyad.isEnabled = false
        }
    }
    
    @IBAction func btnTelEkle_TUI(_ sender: Any) {
        
    }
    
    
    @IBAction func btnKaydet_TUI(_ sender: Any) {
        
        let mesaj = zorunlulukKontrolleri()
        if mesaj == ""
        {
        kisi.Ad = tfAd.text
        kisi.Soyad = tfSoyad.text
        
            if !isUpdate
            {
                Globals.Kisiler.append(kisi)
            }
        
            navigationController!.popViewController(animated: true)
        }
        else
        {
            let ac = UIAlertController(title: "Hata", message: mesaj, preferredStyle: .alert)
        
            ac.addAction(UIAlertAction(title: "Tamam", style: .default, handler: nil))
        
            present(ac, animated: true, completion: nil)
        
        }
        
    }
    
    func zorunlulukKontrolleri()->String
    {
        var mesaj = ""
        if tfAd.text == ""
        {
            mesaj += "Ad boş olamaz."
        }
        if tfSoyad.text == ""
        {
            mesaj += "\nSoyad boş olamaz."
        }
        
        return mesaj
    }

}
