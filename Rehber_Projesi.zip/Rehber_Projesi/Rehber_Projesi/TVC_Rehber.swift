//
//  TVC_Rehber.swift
//  Rehber_Projesi
//
//  Created by Sinan Selek on 10.09.2022.
//

import UIKit

class TVC_Rehber: UITableViewCell {

    @IBOutlet weak var ivCinsiyet: UIImageView!
    @IBOutlet weak var lblAd: UILabel!
    @IBOutlet weak var lblNumber: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
