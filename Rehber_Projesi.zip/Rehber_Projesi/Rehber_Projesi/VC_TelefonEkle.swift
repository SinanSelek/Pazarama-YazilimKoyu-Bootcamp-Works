//
//  VC_TelefonEkle.swift
//  Rehber_Projesi
//
//  Created by Sinan Selek on 15.09.2022.
//

import UIKit

class VC_TelefonEkle: UIViewController, UITableViewDelegate, UITableViewDataSource {
    

    @IBOutlet weak var tvTelefonListe: UITableView!
    @IBOutlet weak var tfTelefon: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Globals.Telefonlar.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "rehberId", for: indexPath) as! TVC_Rehber
        
        let t = Globals.Kisiler[indexPath.row]
        
        cell.lblNumber.text = t.Telefon
    }
    
    
    @IBAction func btnEkle_TUI(_ sender: Any) {
        
        tvTelefonListe.reloadData()
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
