//
//  ViewController.swift
//  05_Listeler
//
//  Created by Sinan Selek on 8.09.2022.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    let liste = ["eleman 1","eleman 2","eleman 3"]
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return liste.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //let cell = UITableViewCell()
                //cell.textLabel?.text = liste[indexPath.row]
                
                if indexPath.row % 2 == 0
                {
                // Yöntem 1
                    let cell = tableView.dequeueReusableCell(withIdentifier: "satirId", for: indexPath) as! TVC_Satir

                    cell.lblMetin.text = liste[indexPath.row]

                    return cell
                
                }
                else
                {
                    // Yöntem 2
                    let cell = Bundle.main.loadNibNamed("TVC_Satir2", owner: self)?.first as! TVC_Satir2
                    
                    cell.lblMetin2.text = liste[indexPath.row]
                    
                    return cell
                }

    }
    
   

}

