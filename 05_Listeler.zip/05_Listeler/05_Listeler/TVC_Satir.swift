//
//  TVC_Satir.swift
//  05_Listeler
//
//  Created by Sinan Selek on 8.09.2022.
//

import UIKit

class TVC_Satir: UITableViewCell {

    @IBOutlet weak var lblMetin: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
