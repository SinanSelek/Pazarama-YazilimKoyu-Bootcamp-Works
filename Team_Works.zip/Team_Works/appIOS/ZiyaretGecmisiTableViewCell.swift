//
//  ZiyaretGecmisiTableViewCell.swift
//  appIOS
//
//  Created by Mine Rala on 21.09.2022.
//

import UIKit

class ZiyaretGecmisiTableViewCell: UITableViewCell {

    @IBOutlet weak var cardView: UIView!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        descriptionLabel.numberOfLines = 3
        cardView.layer.cornerRadius = 6
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 4, left: 0, bottom: 4, right: 0))
    }
    
    func configureCell(time: String, description:  String) {
        timeLabel.text = time
        descriptionLabel.text = description
    }
}
