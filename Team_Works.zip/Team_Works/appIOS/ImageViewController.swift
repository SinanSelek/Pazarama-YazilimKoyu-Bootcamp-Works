//
//  ImageViewController.swift
//  appIOS
//
//  Created by Mine Rala on 21.09.2022.
//

import Foundation
import UIKit

class ImageViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func setImage(image: UIImage) {
        imageView.image = image
    }
}
