//
//  VC_YerEkle.swift
//  Yer_Ekranlari
//
//  Created by Sinan Selek on 20.09.2022.
//

import UIKit

class VC_YerEkle: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    @IBOutlet weak var cvList: UICollectionView!
    
   /* let priority: DropDown = {
        let priority = DropDown()
        priority.dataSource = [
            "Öncelik 1",
            "Öncelik 2",
            "Öncelik 3"
        
        ]
        return priority
    }()*/
    
    @IBOutlet weak var tfLocationName: UITextField!
    @IBOutlet weak var tfLocationDes: UITextField!
    @IBOutlet weak var tfLocationExp: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
       /* let priorityView = UIView(frame: navigationController?.navigationBar.frame ?? .zero)
        myView = priorityView
        guard let view = myView else {return}
        
        priority.anchorView = view
        let gesture = UIGestureRecognizer(target: Self.self, action: #selector(didTap))
        view.addGestureRecognizer(gesture) */
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumInteritemSpacing = 10
        layout.minimumLineSpacing = 0
        cvList.setCollectionViewLayout(layout, animated: true)
        
        self.view.backgroundColor = UIColor(red: 0.898, green: 0.898, blue: 0.898, alpha: 1)

        // Do any additional setup after loading the view.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "placeCell", for: indexPath) as? CVC_PlaceScreen else {return UICollectionViewCell()}
        
        let x = cell.ivPlacePhoto?.image
        DAL.photoAdd(image: [x])
        
        return cell
    }
    
    /*@objc func didTap (){
        priority.show()
    }*/
    
    @IBAction func btnAddLocation_TUI(_ sender: Any) {
        performSegue(withIdentifier: "", sender: nil)
    }
    
    @IBAction func btnPhotoAdd(_ sender: Any) {
        
        
    }
    @IBAction func btnSave_TUI(_ sender: Any) {
    }

}
