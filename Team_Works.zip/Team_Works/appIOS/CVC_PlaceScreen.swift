//
//  CVC_PlaceScreen.swift
//  Yer_Ekranlari
//
//  Created by Sinan Selek on 20.09.2022.
//

import UIKit

class CVC_PlaceScreen: UICollectionViewCell {
    
    @IBOutlet weak var ivPlacePhoto: UIImageView!
    
    @IBAction func btnPlaceDelete(_ sender: Any) {
    }
}
