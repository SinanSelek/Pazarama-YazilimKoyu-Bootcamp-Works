//
//  DAL.swift
//  Yer_Ekranlari
//
//  Created by Sinan Selek on 21.09.2022.
//

import Foundation
import CoreData
import UIKit

class DAL
{
    
    static func getContext() -> NSManagedObjectContext
    {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        return appDelegate.persistentContainer.viewContext
    }
    
    static func photoAdd(image : [UIImage?]){
    
        let context = getContext()
        let entity = NSEntityDescription.entity(forEntityName: "Location", in: context)
        
        let v = NSManagedObject(entity: entity!, insertInto: context)
        
        v.setValue(image, forKey: "image")
        
        do
        {
            try context.save()
        }
        catch{}
    
    }
    
    
    
    static func visitAdd (loc_explanation : String, visit_date : Date, location_name: String, image:  UIImage)
    {
        let context = getContext()
        let entity = NSEntityDescription.entity(forEntityName: "Location", in: context)
        
        let v = NSManagedObject(entity: entity!, insertInto: context)
        
        v.setValue(loc_explanation, forKey: "loc_explanation")
        v.setValue(visit_date, forKey: "visit_date")
        v.setValue(true, forKey: "isVisited")
        v.setValue(loc_explanation, forKey: "loc_explanation")
        v.setValue(location_name, forKey: "location_name")
        if let date = visit_date as? Date {
            v.setValue(date, forKey: "visit_date")
        }
        let image = image
        let data = image.jpegData(compressionQuality: 1.0)

        v.setValue(data, forKey: "image")

        
        do
        {
            try context.save()
        }
        catch{}
    }
    
    static func locationAdd (image : [UIImage],loc_priority : Int16,  location_name : String, loc_description : String, loc_explanation : String)
    {
        let context = getContext()
        let entity = NSEntityDescription.entity(forEntityName: "Location", in: context)
        
        let v = NSManagedObject(entity: entity!, insertInto: context)
        
        v.setValue(loc_description, forKey: "loc_description")
        v.setValue(loc_priority, forKey: "loc_priority")
        v.setValue(loc_explanation, forKey: "loc_explanation")
        v.setValue(location_name, forKey: "location_name")
        v.setValue(image, forKey: "image")
        
        do
        {
            try context.save()
        }
        catch{}
    }
    
    static func getData()
    {
        let fetchRequest : NSFetchRequest<Location> = Location.fetchRequest()
        
        do
        {
            let veriler = try getContext().fetch(fetchRequest)
            
            print(veriler)
        }
        catch{}
    }
    
}
