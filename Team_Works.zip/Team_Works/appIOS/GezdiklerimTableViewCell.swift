//
//  GezdiklerimTableViewCell.swift
//  appIOS
//
//  Created by gaye ugur on 20.09.2022.
//

import UIKit

class GezdiklerimTableViewCell: UITableViewCell {
    
    @IBOutlet var gezdiklerimDescription: UILabel!
    @IBOutlet var gezdiklerimExplanation: UILabel!
    @IBOutlet var gezdiklerimImage: UIImageView!
    @IBOutlet var priorityButton: UIButton!
    @IBOutlet var gezdiklerimName: UILabel!
    @IBOutlet var view: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        priorityButton.layer.cornerRadius = priorityButton.frame.width/2
        priorityButton.layer.masksToBounds = true
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
