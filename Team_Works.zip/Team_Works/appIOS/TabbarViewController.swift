//
//  TabbarViewController.swift
//  appIOS
//
//  Created by gaye ugur on 19.09.2022.
//

import UIKit

class TabbarViewController: UITabBarController {

    @IBOutlet var tabbarController: UITabBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabbarController.layer.cornerRadius = 20
//        let blur = UIBlurEffect(style: UIBlurEffect.Style.dark)
//        let blurView = UIVisualEffectView(effect: blur)
//        blurView.frame = self.tabbarController.bounds
//        self.tabBarController?.tabBar.addSubview(blurView)
        // Do any additional setup after loading the view.
  
    }

}
