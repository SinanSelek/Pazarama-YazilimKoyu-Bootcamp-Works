//
//  Common.swift
//  appIOS
//
//  Created by Mine Rala on 21.09.2022.
//

import UIKit

class Common {
    static func findPriorityColor(_ priorityValue: Int) -> UIColor {
        if priorityValue == 1 {
            return .green
        } else if priorityValue == 2 {
            return .blue
        } else {
            return .gray
        }
    }
}
