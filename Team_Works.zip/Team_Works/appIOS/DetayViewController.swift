//
//  DetayViewController.swift
//  appIOS
//
//  Created by Mine Rala on 20.09.2022.
//

import UIKit
import MapKit

class DetayViewController: UIViewController, UIScrollViewDelegate {
    
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var locationShortDefinitionView: UIView!
    @IBOutlet weak var addVisitButton: UIButton!
    @IBOutlet weak var priorityColorView: UIView!
    @IBOutlet weak var priorityView: UIView!
    @IBOutlet weak var showLocationButton: UIButton!
    @IBOutlet weak var descriptionView: UIView!
    @IBOutlet weak var shortDescriptionLabel: UILabel!
    @IBOutlet weak var visitHistorLabel: UILabel!
    @IBOutlet weak var visitHistoryTableView: UITableView!
    @IBOutlet weak var locationShortDefinitionLabel: UILabel!
    @IBOutlet weak var locationImageView: UIImageView!
 
    let imageList = ["ayasofya", "galata", "indir"]
    
    var frame = CGRect.zero
    var isVisited: Bool = false
    var visitLsit = ["ayasofya", "galata"]
    
    var location: Location!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pageControl.numberOfPages = imageList.count
        self.navigationController?.navigationBar.topItem?.backButtonTitle = ""
        self.navigationController!.navigationBar.tintColor = UIColor.white
        
        setUpImage()
        setUpUI()
        setLocation()
    }
    
    func setUpImage() {
        for index in 0..<imageList.count {
            frame.origin.x = scrollView.frame.size.width * CGFloat(index)
            frame.size = scrollView.frame.size
            let imgView = UIImageView(frame: frame)
            let view = UIView(frame: CGRect(x: 295, y: 294, width: 75, height: 24))
            view.backgroundColor = .red
            imgView.image = UIImage(named: imageList[index])
            self.scrollView.addSubview(imgView)
            imgView.addSubview(view)
//            let topGesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped(image: imgView.image)))
//            imgView.addGestureRecognizer(topGesture)
        }
        scrollView.contentSize = CGSize(width: (scrollView.frame.size.width * CGFloat(imageList.count)), height: scrollView.frame.size.height)
        scrollView.delegate = self
    }
    
    func setLocation () {
        title = location.location_name
        priorityColorView.backgroundColor = Common.findPriorityColor(Int(location.loc_priority))
        locationShortDefinitionLabel.text = location.loc_explanation
        shortDescriptionLabel.text = location.loc_description
        //visitLsit = location.vis
        isVisited = location.isVisited
        
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let pageNumber = scrollView.contentOffset.x / scrollView.frame.size.width
        pageControl.currentPage = Int(pageNumber)
    }
    
    private func setUpUI() {
        priorityView.layer.cornerRadius = 6
        priorityColorView.layer.cornerRadius = priorityColorView.frame.width/2
        addVisitButton.layer.cornerRadius = 6
        showLocationButton.layer.cornerRadius = 6
        locationShortDefinitionView.layer.cornerRadius = 4
        descriptionView.layer.cornerRadius = 6
        shortDescriptionLabel.numberOfLines = 3
        visitHistoryTableView.reloadData()
        
        if isVisited == false {
            visitHistorLabel.isHidden = true
            visitHistoryTableView.isHidden = true
        } else {
            visitHistorLabel.isHidden = false
            visitHistoryTableView.isHidden = false
        }

    }
}

//MARK: - Actions
extension DetayViewController {
    
    @IBAction func addVisitButtonAction(_ sender: Any) {
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? KonumViewController {
            vc.title = location.location_name
            vc.longitude = location.loc_long as? Double
            vc.latitude = location.log_lat as? Double
        }
    }
    
    @objc func imageTapped(image: UIImage) {
        let imageVC = ImageViewController()
        imageVC.setImage(image: image)
        self.navigationController?.pushViewController(imageVC, animated: true)
    
    }
}

extension DetayViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return visitLsit.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = Bundle.main.loadNibNamed("ZiyaretGecmisiTableViewCell", owner: self, options: nil)?.first as! ZiyaretGecmisiTableViewCell
        cell.configureCell(time: visitLsit[indexPath.row], description: visitLsit[indexPath.row])
        return cell
    }
    
    
    
}
