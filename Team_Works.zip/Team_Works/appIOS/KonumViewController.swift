//
//  KonumViewController.swift
//  appIOS
//
//  Created by Mine Rala on 21.09.2022.
//

import Foundation
import UIKit
import MapKit

class KonumViewController: UIViewController {
    @IBOutlet weak var locationView: MKMapView!
    @IBOutlet weak var goButton: UIButton!
    var latitude: Double!
    var longitude: Double!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.topItem?.backButtonTitle = ""
        self.navigationController!.navigationBar.tintColor = UIColor.white
        goButton.layer.cornerRadius = 6
        let location = CLLocation(latitude: 41.042058, longitude: 28.996780)
        let coordinateRegion = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 7000, longitudinalMeters: 7000)
        locationView.setRegion(coordinateRegion, animated: true)
    }
    
    @IBAction func goButtonAction(_ sender: Any) {
       print("Google Maps")
    }
}
