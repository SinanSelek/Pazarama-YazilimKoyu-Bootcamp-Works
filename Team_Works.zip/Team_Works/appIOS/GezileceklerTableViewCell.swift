//
//  TableViewCell.swift
//  appIOS
//
//  Created by gaye ugur on 20.09.2022.
//

import UIKit

class GezileceklerTableViewCell : UITableViewCell {

    @IBOutlet var priorityButton: UIButton!
    @IBOutlet var visitimageView: UIImageView!
    @IBOutlet var visitNameLabel: UILabel!
    @IBOutlet var visitShortDescription: UILabel!
    @IBOutlet var visitShortExplanation: UILabel!
    @IBOutlet var view: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        priorityButton.layer.cornerRadius = priorityButton.frame.width/2
        priorityButton.layer.masksToBounds = true
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
 
}
