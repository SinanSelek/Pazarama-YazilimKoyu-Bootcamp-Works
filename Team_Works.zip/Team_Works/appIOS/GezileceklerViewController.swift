//
//  GezileceklerViewController.swift
//  appIOS
//
//  Created by gaye ugur on 19.09.2022.
//

import UIKit
import CoreData

class GezileceklerViewController: UIViewController {

    @IBOutlet var gezileceklerTableView: UITableView!
    var gezilecekNameArray = [[String]]()
    var priorityArray = [Int]()
    var imageArray = [UIImage]()
    var locationList = [Location]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        gezileceklerTableView.delegate = self
        gezileceklerTableView.dataSource = self
        gezileceklerTableView.backgroundColor = .systemGray5
        self.navigationItem.title = "Gezilecekler"
        
        let appearance = UINavigationBarAppearance()
        appearance.backgroundColor = .systemBlue
        appearance.titleTextAttributes = [.foregroundColor : UIColor.white]
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.compactAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance

        addData()
        addData2()
        getData()
    }
    func addData(){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let visited = NSEntityDescription.insertNewObject(forEntityName: "Location", into: context)
        visited.setValue(true, forKey: "isVisited")
        visited.setValue("MS 27 Aralık 537 açılmıştır", forKey: "loc_description")
        visited.setValue("Ayasofya-i Kebîr Câmi-i Şerîfi, İstanbul'da yer alan bir cami ve müzedir.", forKey: "loc_explanation")
        visited.setValue(1, forKey: "loc_priority")
        visited.setValue("Ayasofya Cami", forKey: "location_name")
        visited.setValue(Date(), forKey: "visit_date")
        
        let image = UIImage(named: "ayasofya")
        let data = image!.jpegData(compressionQuality: 1.0)
 
        visited.setValue(data, forKey: "image")
        do {
            try  context.save()
            print("success")
        }catch {
            print("error")
        }
       
    }
    func addData2(){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let visited2 = NSEntityDescription.insertNewObject(forEntityName: "Location", into: context)
        visited2.setValue(false, forKey: "isVisited")
        visited2.setValue("Adını, bulunduğu Galata semtinden alır.", forKey: "loc_description")
        visited2.setValue("Türkiye'nin İstanbul şehrinin Beyoğlu ilçesinde bulunan bir kuledir.", forKey: "loc_explanation")
        visited2.setValue(2, forKey: "loc_priority")
        visited2.setValue("Galata Kulesi", forKey: "location_name")
        visited2.setValue(Date(), forKey: "visit_date")
        
        let image = UIImage(named: "galata")
        let data = image!.jpegData(compressionQuality: 1.0)
 
        visited2.setValue(data, forKey: "image")
        do {
            try  context.save()
            print("success")
        }catch {
            print("error")
        }
       
    }
    override func viewWillAppear(_ animated: Bool) {
        getData()
        self.gezileceklerTableView.reloadData()
    }

    
    func getData() {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let fetchRquest = NSFetchRequest<NSFetchRequestResult>(entityName: "Location")
        fetchRquest.returnsObjectsAsFaults = false
        var nameArray = [String]()
        var descriptArray = [String]()
        var expArray = [String]()
        
        do {
            let results = try context.fetch(fetchRquest)
            for result in results as! [NSManagedObject] {
                if let isVisited = result.value(forKey: "isVisited") as? Bool {
                    if !isVisited  {
                        if let name = result.value(forKey: "location_name") as? String {
                            nameArray.append(name)
                        }
                        if let descript = result.value(forKey: "loc_description") as? String {
                            descriptArray.append(descript)
                        }
                        if let explanation = result.value(forKey: "loc_explanation") as? String {
                            expArray.append(explanation)
                        }
                        if let priority = result.value(forKey: "loc_priority") as? Int {
                            priorityArray.append(priority)
                        }
                        if let imageData = result.value(forKey: "image") as? Data {
                            let image = UIImage(data: imageData)
                            imageArray.append(image!)
                        }
                    }
                }
                let location = result as! Location
                locationList.append(location)
            }
            
            gezilecekNameArray.append(nameArray)
            gezilecekNameArray.append(descriptArray)
            gezilecekNameArray.append(expArray)
            gezileceklerTableView.reloadData()
   
        }catch {
            print("error")
        }
    }
}


extension GezileceklerViewController : UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        getData()
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = gezileceklerTableView.dequeueReusableCell(withIdentifier: "toGezilecekler", for: indexPath) as! GezileceklerTableViewCell
        cell.visitNameLabel.text = gezilecekNameArray[0][indexPath.row]
        cell.visitShortDescription.text = gezilecekNameArray[1][indexPath.row]
        cell.visitShortExplanation.text = gezilecekNameArray[2][indexPath.row]
        let color = Common.findPriorityColor(priorityArray[indexPath.row])
        cell.priorityButton.backgroundColor = color
        cell.visitimageView?.image = imageArray[indexPath.row]
        cell.view.layer.cornerRadius = 10
        return cell
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return gezilecekNameArray.count/3
    }
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "gezilecekDetay", sender: indexPath.row)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "gezilecekDetay" {
            let vc = segue.destination as! DetayViewController
            vc.location = locationList[sender as! Int]
        }
    }
}
