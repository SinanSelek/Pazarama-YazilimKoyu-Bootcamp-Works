//
//  CVC_Photo.swift
//  Yer_Ekranlari
//
//  Created by Sinan Selek on 20.09.2022.
//

import UIKit

class CVC_Photo: UICollectionViewCell {
    
    @IBOutlet weak var ivPhoto: UIImageView!
    
    
    @IBAction func btnDelete_TUI(_ sender: Any) {
        
    }
}
