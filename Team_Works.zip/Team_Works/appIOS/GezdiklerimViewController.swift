//
//  GezdiklerimViewController.swift
//  appIOS
//
//  Created by gaye ugur on 20.09.2022.
//

import UIKit
import CoreData

class GezdiklerimViewController: UIViewController {
    var gezdiklerimArray = [[String]]()
    var priorityArray = [Int]()
    var locationList = [Location]()

    @IBOutlet var gezdiklerimTableView: UITableView!
    override func viewDidLoad() {
        gezdiklerimTableView.reloadData()

        super.viewDidLoad()
        gezdiklerimTableView.delegate = self
        gezdiklerimTableView.dataSource = self
        gezdiklerimTableView.backgroundColor = .systemGray5
        
        self.navigationItem.title = "Gezdiklerim"
        let appearance = UINavigationBarAppearance()
        appearance.backgroundColor = .systemBlue
        appearance.titleTextAttributes = [.foregroundColor : UIColor.white]
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.compactAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        getData()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        getData()
        self.gezdiklerimTableView.reloadData()
    }
    func getData() {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let fetchRquest = NSFetchRequest<NSFetchRequestResult>(entityName: "Location")
        fetchRquest.returnsObjectsAsFaults = false
        
        do {
            var nameArray = [String]()
            var descriptArray = [String]()
            var expArray = [String]()
            
            let results = try context.fetch(fetchRquest)
            for result in results as! [NSManagedObject] {
                if let isVisited = result.value(forKey: "isVisited") as? Bool {
                    if isVisited {
                        if let name = result.value(forKey: "location_name") as? String {
                            nameArray.append(name)
                        }
                        if let descript = result.value(forKey: "loc_description") as? String {
                            descriptArray.append(descript)
                        }
                        if let explanation = result.value(forKey: "loc_explanation") as? String {
                            expArray.append(explanation)
                        }
                        if let priority = result.value(forKey: "loc_priority") as? Int {
                            priorityArray.append(priority)
                        }
                    }
                }
                let location = result as! Location
                locationList.append(location)
            }
            gezdiklerimArray.append(nameArray)
            gezdiklerimArray.append(descriptArray)
            gezdiklerimArray.append(expArray)
            gezdiklerimTableView.reloadData()
        }catch {
            print("error")
        }
    }
}
extension GezdiklerimViewController : UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = gezdiklerimTableView.dequeueReusableCell(withIdentifier: "toGezdiklerim", for: indexPath) as! GezdiklerimTableViewCell
        cell.gezdiklerimName.text = gezdiklerimArray[0][indexPath.row]
        cell.gezdiklerimDescription.text = gezdiklerimArray[1][indexPath.row]
        cell.gezdiklerimExplanation.text = gezdiklerimArray[2][indexPath.row]
        let color = Common.findPriorityColor(priorityArray[indexPath.row])
        cell.priorityButton.backgroundColor = color
        cell.view.layer.cornerRadius = 10
        return cell

    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return gezdiklerimArray.count/3
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "gezdiklerimDetay", sender: indexPath.row)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "gezdiklerimDetay" {
            let vc = segue.destination as! DetayViewController
            vc.location = locationList[sender as! Int]
        }
        
    }


}
