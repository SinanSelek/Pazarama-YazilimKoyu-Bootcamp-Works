//
//  main.swift
//  Arac_Modelleme(Kalitim)
//
//  Created by Sinan Selek on 21.08.2022.
//

import Foundation

class Arac
{
    var tekerlekSayisi : Int?
    var yolcuKapasitesi : Int?
    var ileriGitmeOzelligi : Bool?
    var geriGitmeOzelligi : Bool?
    
    init(yolcukap : Int)
    {
        yolcuKapasitesi = yolcukap
    }
}

class Otomobil : Arac
{
    init()
    {
        super.init(yolcukap: 4)
    }
}

class Kamyon : HizLimitliArac
{
    var yukKapasitesi : Int?
    
    init()
    {
        super.init(yolcukap: 2)
    }
}

class Otobus : HizLimitliArac
{
    var bagajKapasitesi : Int?
    var mutfakOzelligi : Bool?
    
    init()
    {
        super.init(yolcukap: 55)
    }
}

class HizLimitliArac : Arac
{
    let hizLimiti = 88
}

